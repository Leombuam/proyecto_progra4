// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB6xHgFKCjxaxYWxCwP4VEPoCJEFFqxbe4",
  authDomain: "proyecto-progra4-c8bed.firebaseapp.com",
  projectId: "proyecto-progra4-c8bed",
  storageBucket: "proyecto-progra4-c8bed.appspot.com",
  messagingSenderId: "732748357801",
  appId: "1:732748357801:web:db01e16d3c9a9f6dba89b8"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export  default app;
